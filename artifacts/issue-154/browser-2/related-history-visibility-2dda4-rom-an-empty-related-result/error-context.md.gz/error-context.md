# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: related-history-visibility.spec.ts >> keeps loading and retryable errors separate from an empty related result
- Location: e2e/related-history-visibility.spec.ts:136:5

# Error details

```
ReferenceError: testInfo is not defined
```

# Page snapshot

```yaml
- generic [ref=f1e2]:
  - generic [ref=f1e5]:
    - complementary [ref=f1e6]:
      - generic [ref=f1e7]:
        - generic [ref=f1e8]:
          - paragraph [ref=f1e9]: Pulse
          - button "Collapse sidebar" [ref=f1e10] [cursor=pointer]
        - navigation "Desktop navigation" [ref=f1e13]:
          - link "Dashboard" [ref=f1e14] [cursor=pointer]:
            - /url: /
          - link "Workouts" [ref=f1e21] [cursor=pointer]:
            - /url: /workouts
          - link "Nutrition" [ref=f1e29] [cursor=pointer]:
            - /url: /nutrition
          - link "Habits" [ref=f1e36] [cursor=pointer]:
            - /url: /habits
          - link "Data Quality" [ref=f1e41] [cursor=pointer]:
            - /url: /data-quality
          - link "Activity" [ref=f1e46] [cursor=pointer]:
            - /url: /activity
          - link "Journal" [ref=f1e50] [cursor=pointer]:
            - /url: /journal
          - link "Profile" [ref=f1e55] [cursor=pointer]:
            - /url: /profile
        - generic [ref=f1e60]:
          - link "R Related History Preview @related-history-872587bd" [ref=f1e61] [cursor=pointer]:
            - /url: /profile
            - generic [ref=f1e62]: R
            - generic [ref=f1e63]:
              - paragraph [ref=f1e64]: Related History Preview
              - paragraph [ref=f1e65]: "@related-history-872587bd"
          - button "Log out" [ref=f1e66] [cursor=pointer]
    - main [ref=f1e71]:
      - generic [ref=f1e72]:
        - generic [ref=f1e73]:
          - generic [ref=f1e74]:
            - generic [ref=f1e75]: Set progress
            - generic [ref=f1e76]: 0 / 3
          - progressbar "Workout progress" [ref=f1e77]
        - generic [ref=f1e80]:
          - generic [ref=f1e81]:
            - generic [ref=f1e82]:
              - paragraph [ref=f1e83]: Active session
              - generic [ref=f1e84]:
                - heading "Related History Acceptance" [level=1] [ref=f1e85]
                - paragraph [ref=f1e86]: Exercise 1 of 3
                - paragraph [ref=f1e87]: ~3 min total estimate
            - generic [ref=f1e88]:
              - generic [ref=f1e89]:
                - generic [ref=f1e90]: Total time
                - paragraph [ref=f1e95]: 00:00
              - generic [ref=f1e96]:
                - generic [ref=f1e97]: Exercises
                - paragraph [ref=f1e105]: 1/3
              - generic [ref=f1e106]:
                - generic [ref=f1e107]: Sets done
                - paragraph [ref=f1e112]: 0/3
              - generic [ref=f1e113]:
                - paragraph [ref=f1e114]: Estimated
                - paragraph [ref=f1e115]: ~3 min
          - generic [ref=f1e116]:
            - generic [ref=f1e117]: Start time
            - button "9:00 AM" [ref=f1e118] [cursor=pointer]
        - button "Workout session options" [ref=f1e120] [cursor=pointer]
        - region "Session context" [ref=f1e121]:
          - button [expanded] [ref=f1e122] [cursor=pointer]:
            - generic [ref=f1e123]:
              - heading "Session Context" [level=2] [ref=f1e124]
              - paragraph [ref=f1e125]: Training context and readiness notes
          - generic [ref=f1e128]:
            - note [ref=f1e129]:
              - generic [ref=f1e130]:
                - paragraph [ref=f1e133]: Some cards are in preview — sample data is shown and won't be saved.
                - button "Dismiss preview banner" [ref=f1e134] [cursor=pointer]: Dismiss
            - generic [ref=f1e135]:
              - generic [ref=f1e136]:
                - generic [ref=f1e138]:
                  - paragraph [ref=f1e140]: Recent Training
                  - paragraph [ref=f1e141]: Last 3 sessions
                - list [ref=f1e148]:
                  - listitem [ref=f1e149]:
                    - generic [ref=f1e150]:
                      - paragraph [ref=f1e151]: Newer unusable performance
                      - paragraph [ref=f1e152]: Sep 2
                    - paragraph [ref=f1e153]: 5 days ago
                  - listitem [ref=f1e154]:
                    - generic [ref=f1e155]:
                      - paragraph [ref=f1e156]: Older meaningful performance
                      - paragraph [ref=f1e157]: Sep 1
                    - paragraph [ref=f1e158]: 6 days ago
              - generic [ref=f1e159]:
                - generic [ref=f1e161]:
                  - generic [ref=f1e162]:
                    - paragraph [ref=f1e163]: Recovery Status
                    - generic [ref=f1e164]: Preview
                  - paragraph [ref=f1e165]: Sleep and readiness
                - generic [ref=f1e174]:
                  - paragraph [ref=f1e175]: Good sleep
                  - paragraph [ref=f1e176]: Recovery looks stable for today's training.
              - generic [ref=f1e177]:
                - generic [ref=f1e179]:
                  - generic [ref=f1e180]:
                    - paragraph [ref=f1e181]: Active Injuries
                    - generic [ref=f1e182]: Preview
                  - paragraph [ref=f1e183]: Conditions to respect today
                - generic [ref=f1e188]:
                  - generic [ref=f1e189]: 2 active
                  - list [ref=f1e190]:
                    - listitem [ref=f1e191]:
                      - generic [ref=f1e194]: Left shoulder SLAP tear
                    - listitem [ref=f1e195]:
                      - generic [ref=f1e198]: Right patellar tendon irritation
              - generic [ref=f1e199]:
                - generic [ref=f1e201]:
                  - generic [ref=f1e202]:
                    - paragraph [ref=f1e203]: Training Phase
                    - generic [ref=f1e204]: Preview
                  - paragraph [ref=f1e205]: Current program block
                - generic [ref=f1e212]:
                  - generic [ref=f1e213]: Rebuild Phase
                  - paragraph [ref=f1e214]: Accumulation Block 2 - Rebuild
        - generic [ref=f1e216]:
          - generic [ref=f1e217]:
            - button "Main 1-5 min Main elapsed time 0/3" [expanded] [ref=f1e218] [cursor=pointer]:
              - generic [ref=f1e219]:
                - heading "Main 1-5 min" [level=2] [ref=f1e220]:
                  - text: Main
                  - generic [ref=f1e221]: 1-5 min
                - paragraph [ref=f1e222]: 00:00
              - generic [ref=f1e223]: 0/3
            - button "Start" [ref=f1e227] [cursor=pointer]
          - generic [ref=f1e228]:
            - generic [ref=f1e229]:
              - generic [ref=f1e230]:
                - 'button "In-progress exercise Mixed Preview Press 0/1 sets· 1-3 min #1 Exercise actions for Mixed Preview Press" [expanded] [active] [ref=f1e231] [cursor=pointer]':
                  - generic [ref=f1e232]:
                    - generic [ref=f1e233]:
                      - generic "In-progress exercise" [ref=f1e234]
                      - generic [ref=f1e237]:
                        - heading "Mixed Preview Press" [level=3] [ref=f1e238]
                        - paragraph [ref=f1e239]: 0/1 sets· 1-3 min
                    - generic [ref=f1e240]: "#1"
                  - button "Exercise actions for Mixed Preview Press" [ref=f1e244]
                - generic [ref=f1e246]:
                  - generic [ref=f1e247]:
                    - paragraph [ref=f1e248]: 1 sets × reps
                    - generic [ref=f1e249]:
                      - generic [ref=f1e250]: Compound
                      - generic [ref=f1e251]: "Tempo: 2-1-1-1"
                      - generic [ref=f1e252]: "Rest: 60s"
                    - generic [ref=f1e254]:
                      - generic [ref=f1e255]:
                        - paragraph [ref=f1e256]: History
                        - button "View all" [ref=f1e257] [cursor=pointer]
                      - generic [ref=f1e261]:
                        - paragraph [ref=f1e262]: Sep 1 · 0x8 (0 RIR)
                        - 'button "Effort details: History, 2026-09-01" [ref=f1e263] [cursor=pointer]': Effort details
                        - button "View notes" [ref=f1e264] [cursor=pointer]
                    - group [ref=f1e266]:
                      - generic "Related Related history" [ref=f1e267] [cursor=pointer]:
                        - generic [ref=f1e268]:
                          - generic [ref=f1e269]: Related
                          - paragraph [ref=f1e270]: Related history
                  - generic [ref=f1e274]:
                    - generic [ref=f1e275]: Set 1
                    - generic [ref=f1e276]:
                      - generic [ref=f1e277]:
                        - spinbutton "Weight for set 1" [ref=f1e278]
                        - generic [ref=f1e279]: lbs
                      - generic [ref=f1e280]: ×
                      - generic [ref=f1e281]:
                        - spinbutton "Reps for set 1" [ref=f1e282]
                        - generic [ref=f1e283]: reps
                    - generic [ref=f1e285]:
                      - 'button "RIR for set 1: No repetitions in reserve logged" [ref=f1e286] [cursor=pointer]': RIR —
                      - generic [ref=f1e287]: Type 0–5 to set RIR; 5 means 5 or more.
                  - group [ref=f1e288]:
                    - generic "Session notes" [ref=f1e289] [cursor=pointer]
              - 'button "Upcoming exercise Empty Preview Press 0/1 sets· 1-3 min #2 Exercise actions for Empty Preview Press" [ref=f1e293] [cursor=pointer]':
                - generic [ref=f1e294]:
                  - generic [ref=f1e295]:
                    - generic "Upcoming exercise" [ref=f1e296]
                    - generic [ref=f1e299]:
                      - heading "Empty Preview Press" [level=3] [ref=f1e300]
                      - paragraph [ref=f1e301]: 0/1 sets· 1-3 min
                  - generic [ref=f1e302]: "#2"
                - button "Exercise actions for Empty Preview Press" [ref=f1e306]
              - 'button "Upcoming exercise Direct Only Press 0/1 sets· 1-3 min #3 Exercise actions for Direct Only Press" [ref=f1e308] [cursor=pointer]':
                - generic [ref=f1e309]:
                  - generic [ref=f1e310]:
                    - generic "Upcoming exercise" [ref=f1e311]
                    - generic [ref=f1e314]:
                      - heading "Direct Only Press" [level=3] [ref=f1e315]
                      - paragraph [ref=f1e316]: 0/1 sets· 1-3 min
                  - generic [ref=f1e317]: "#3"
                - button "Exercise actions for Direct Only Press" [ref=f1e321]
            - status [ref=f1e322]
        - generic [ref=f1e323]:
          - button "Complete Workout" [ref=f1e324] [cursor=pointer]
          - paragraph [ref=f1e325]: 0/3 sets completed
  - region "Notifications alt+T"
```

# Test source

```ts
  69  |       const disclosure = mixedPanel
  70  |         .locator('details')
  71  |         .filter({ has: page.getByText('Related history', { exact: true }) });
  72  |       const summary = disclosure.locator('summary');
  73  |       await expect(summary).toBeVisible();
  74  |       await expect(disclosure).not.toHaveAttribute('open');
  75  |       // Reach the summary through real keyboard navigation from the preceding direct-history control.
  76  |       await mixedPanel.getByRole('button', { name: 'View all', exact: true }).focus();
  77  |       for (
  78  |         let i = 0;
  79  |         i < 40 && !(await summary.evaluate((el) => el === document.activeElement));
  80  |         i++
  81  |       )
  82  |         await page.keyboard.press('Tab');
  83  |       await expect(summary).toBeFocused();
  84  |       await page.keyboard.press('Enter');
  85  |       await expect(disclosure).toHaveAttribute('open');
  86  |       await page.keyboard.press('Space');
  87  |       await expect(disclosure).not.toHaveAttribute('open');
  88  |       await page.keyboard.press('Enter');
  89  |       for (const name of ['Unused Variation', 'Unstarted Variation', 'Skipped Variation'])
  90  |         await expect(disclosure.getByText(name, { exact: true })).toHaveCount(0);
  91  |       for (const exercise of fixture.related)
  92  |         await expect(disclosure.getByText(exercise.name, { exact: true })).toBeVisible();
  93  |       await expect(disclosure.getByText('Sep 1 · 0x8 (0 RIR)', { exact: true })).toBeVisible();
  94  |       await expect(disclosure.getByText('Sep 1 · 8 (0 RIR)', { exact: true })).toBeVisible();
  95  |       await expect(disclosure.getByText('Sep 1 · 0s', { exact: true })).toBeVisible();
  96  |       await expect(disclosure.getByText('Sep 1 · 0mi', { exact: true })).toBeVisible();
  97  |       await disclosure.getByRole('button', { name: 'View notes', exact: true }).first().click();
  98  |       await expect(page.getByText('Preserved historical note.', { exact: true })).toBeVisible();
  99  |       await page.keyboard.press('Escape');
  100 |       await disclosure
  101 |         .getByRole('button', { name: 'Effort details: History, 2026-09-01', exact: true })
  102 |         .first()
  103 |         .click();
  104 |       await expect(page.getByRole('dialog', { name: 'Effort details', exact: true })).toContainText(
  105 |         'Stored RIR: 0',
  106 |       );
  107 |       await page.keyboard.press('Escape');
  108 |       await mixedPanel.screenshot({ path: testInfo.outputPath('mixed-related.png') });
  109 |       await disclosure.getByRole('button', { name: 'View all', exact: true }).first().click();
  110 |       await expect(page.getByRole('dialog')).toContainText(fixture.related[0].name);
  111 |       await expect(
  112 |         page.getByRole('dialog').getByText('Session history', { exact: true }),
  113 |       ).toBeVisible();
  114 |       await page.keyboard.press('Escape');
  115 |       await summary.click();
  116 |       await mixedPanel.getByRole('button', { name: 'View all', exact: true }).click();
  117 |       await expect(page.getByRole('dialog')).toContainText(fixture.mixed.name);
  118 |       await expect(
  119 |         page.getByRole('dialog').getByText('Session history', { exact: true }),
  120 |       ).toBeVisible();
  121 |       await page.keyboard.press('Escape');
  122 |       expect(
  123 |         await page.evaluate(
  124 |           () => document.documentElement.scrollWidth <= document.documentElement.clientWidth,
  125 |         ),
  126 |       ).toBe(true);
  127 |       for (const session of [fixture.older, fixture.newer, fixture.active])
  128 |         expect(await fixture.api<WorkoutSession>(`/workout-sessions/${session.id}`)).toEqual(
  129 |           session,
  130 |         );
  131 |       expect(errors).toEqual([]);
  132 |     });
  133 |   });
  134 | }
  135 | 
  136 | test('keeps loading and retryable errors separate from an empty related result', async ({
  137 |   page,
  138 | }) => {
  139 |   const fixture = await seedRelatedHistoryFixture(apiBaseURL);
  140 |   let release!: () => void;
  141 |   const pending = new Promise<void>((resolve) => {
  142 |     release = resolve;
  143 |   });
  144 |   let requests = 0;
  145 |   await page.route(`**/exercises/${fixture.mixed.id}/last-performance?**`, async (route) => {
  146 |     requests++;
  147 |     if (requests === 1) {
  148 |       await pending;
  149 |       await route.fulfill({
  150 |         status: 503,
  151 |         contentType: 'application/json',
  152 |         body: JSON.stringify({
  153 |           error: { code: 'UNAVAILABLE', message: 'Synthetic retryable failure' },
  154 |         }),
  155 |       });
  156 |     } else await route.continue();
  157 |   });
  158 |   await setAuthenticatedSession(page, fixture.token);
  159 |   await page.goto(`/workouts/active?sessionId=${fixture.active.id}`);
  160 |   const mixedPanel = await panel(page, fixture.mixed);
  161 |   await expect.poll(() => requests).toBe(1);
  162 |   await expect(mixedPanel.getByText('Related history', { exact: true })).toHaveCount(0);
  163 |   await expect(mixedPanel.getByText('No completed sets yet.', { exact: true })).toHaveCount(0);
  164 |   await expect(mixedPanel.getByText('History', { exact: true })).toBeVisible();
  165 |   release();
  166 |   await expect(mixedPanel.getByText('Related history', { exact: true })).toBeVisible();
  167 |   expect(requests).toBe(2);
  168 |   writeFileSync(
> 169 |     testInfo.outputPath('retry.json'),
      |     ^ ReferenceError: testInfo is not defined
  170 |     JSON.stringify(
  171 |       {
  172 |         injectedStatus: 503,
  173 |         requests,
  174 |         recovered: true,
  175 |         directHistoryVisibleDuringLoading: true,
  176 |         fabricatedEmptyDisclosure: false,
  177 |       },
  178 |       null,
  179 |       2,
  180 |     ) + '\n',
  181 |   );
  182 | });
  183 | 
```